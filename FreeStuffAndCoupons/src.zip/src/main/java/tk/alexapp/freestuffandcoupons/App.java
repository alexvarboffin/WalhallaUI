package tk.alexapp.freestuffandcoupons;

import com.google.android.gms.ads.MobileAds;
import com.google.firebase.FirebaseApp;

import android.app.Application;

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        FirebaseApp.initializeApp(this);
        MobileAds.initialize(this, "ca-app-pub-8573994824830166~1485264971");
    }
}
